def next_number(existing):
    """Find the next INV sequence number."""
    numbers = [int(number.split('-')[-1]) for number in existing]
    return f"INV-{max(numbers, default=0) + 1}"
