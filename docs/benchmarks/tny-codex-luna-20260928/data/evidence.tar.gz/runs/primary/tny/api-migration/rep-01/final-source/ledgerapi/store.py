"""Versioned tenant record resolution."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Record:
    scope: str
    identifier: str
    value: object
    revision: int
    expires_at: int | None = None
    deleted: bool = False


@dataclass(frozen=True)
class Resolution:
    found: bool
    value: object
    revision: int | None
    reason: str


class RecordStore:
    def __init__(self, records=()):
        self.records = list(records)

    def resolve(self, scope, identifier, *, as_of=None):
        if as_of is not None and as_of < 0:
            raise ValueError("as_of must be nonnegative")
        matching = [r for r in self.records if r.scope == scope and r.identifier == identifier
                    and (as_of is None or r.revision <= as_of)]
        if not matching:
            return Resolution(False, None, None, "absent")
        record = max(matching, key=lambda r: r.revision)
        if record.deleted:
            return Resolution(False, None, record.revision, "deleted")
        clock = as_of if as_of is not None else max(r.revision for r in self.records)
        if record.expires_at is not None and clock >= record.expires_at:
            return Resolution(False, None, record.revision, "expired")
        return Resolution(True, record.value, record.revision, "found")

    def append(self, record):
        self.records.append(record)
