# Record access

`RecordStore.resolve(scope, identifier, *, as_of=None)` returns a `Resolution`
with `found`, `value`, `revision`, and `reason`. Reasons are `found`, `absent`,
`deleted`, and `expired`. Explicit null values are found; clients use fallback
only when `found` is false. Historical reads select the newest record at or
before `as_of`; tombstones mask older values. Expiry is evaluated at the query
revision, or at the store head for current reads. Negative revisions are invalid.

Client readers retain their public signatures and key format. Historical
readers pass `as_of` through to `resolve`.
