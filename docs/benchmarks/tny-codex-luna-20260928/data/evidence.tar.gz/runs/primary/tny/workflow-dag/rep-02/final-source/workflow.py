import re

_ID = re.compile(r"[A-Za-z][A-Za-z0-9_-]{0,31}\Z", re.ASCII)


def _integer(value, low, high):
    return isinstance(value, int) and not isinstance(value, bool) and low <= value <= high


def simulate(tasks, workers=2, retries=1):
    if not _integer(workers, 1, 8) or not _integer(retries, 0, 8):
        raise ValueError
    if not isinstance(tasks, list) or len(tasks) > 32:
        raise ValueError
    by_id = {}
    for task in tasks:
        if not isinstance(task, dict) or set(task) - {"id", "duration", "depends_on", "failures"}:
            raise ValueError
        ident = task.get("id")
        if not isinstance(ident, str) or not _ID.fullmatch(ident) or ident in by_id:
            raise ValueError
        duration = task.get("duration")
        failures = task.get("failures", 0)
        deps = task.get("depends_on", [])
        if not _integer(duration, 1, 1000) or not _integer(failures, 0, 8) or not isinstance(deps, list):
            raise ValueError
        if any(not isinstance(d, str) for d in deps) or len(set(deps)) != len(deps):
            raise ValueError
        by_id[ident] = {"duration": duration, "failures": failures, "deps": deps}
    for ident, task in by_id.items():
        if any(dep not in by_id or dep == ident for dep in task["deps"]):
            raise ValueError
    # Validate acyclicity before any simulation.
    visiting, visited = set(), set()
    def visit(node):
        if node in visiting:
            raise ValueError
        if node in visited:
            return
        visiting.add(node)
        for dep in by_id[node]["deps"]:
            visit(dep)
        visiting.remove(node)
        visited.add(node)
    for ident in by_id:
        visit(ident)

    states = {i: "pending" for i in by_id}
    attempts = {i: 0 for i in by_id}
    finishes = {}
    running = {}  # task -> finish time
    events = []
    now = 0
    while any(s in ("pending", "running") for s in states.values()):
        if running:
            now = min(running.values())
            completed = sorted(i for i, end in running.items() if end == now)
            for ident in completed:
                del running[ident]
                n = attempts[ident]
                if n <= by_id[ident]["failures"]:
                    if n <= retries:
                        states[ident] = "pending"
                        typ = "retry"
                    else:
                        states[ident] = "failed"
                        finishes[ident] = now
                        typ = "failed"
                else:
                    states[ident] = "succeeded"
                    finishes[ident] = now
                    typ = "succeeded"
                events.append({"time": now, "task": ident, "attempt": n, "type": typ})
        # Propagate skips in lexicographic waves after all completions.
        while True:
            skipped = [i for i, s in states.items() if s == "pending" and any(states[d] in ("failed", "skipped") for d in by_id[i]["deps"])]
            if not skipped:
                break
            for ident in sorted(skipped):
                states[ident] = "skipped"
                finishes[ident] = now
                events.append({"time": now, "task": ident, "attempt": 0, "type": "skipped"})
        slots = workers - len(running)
        ready = sorted(i for i, s in states.items() if s == "pending" and all(states[d] == "succeeded" for d in by_id[i]["deps"]))
        for ident in ready[:slots]:
            attempts[ident] += 1
            states[ident] = "running"
            running[ident] = now + by_id[ident]["duration"]
            events.append({"time": now, "task": ident, "attempt": attempts[ident], "type": "start"})
        if not running and any(s == "pending" for s in states.values()):
            # Only possible for malformed internal state; cycles validated.
            raise ValueError
    result = {i: {"state": states[i], "attempts": attempts[i], "finish": finishes[i]} for i in by_id}
    return {"makespan": max(finishes.values(), default=0), "tasks": result, "events": events}
