import re

_ID = re.compile(r"[A-Za-z][A-Za-z0-9_-]{0,31}\Z", re.ASCII)

def _integer(value, low, high):
    return isinstance(value, int) and not isinstance(value, bool) and low <= value <= high

def simulate(tasks, workers=2, retries=1):
    if not isinstance(tasks, list) or len(tasks) > 32:
        raise ValueError
    if not _integer(workers, 1, 8) or not _integer(retries, 0, 8):
        raise ValueError
    data = {}
    for task in tasks:
        if not isinstance(task, dict) or set(task) - {"id", "duration", "depends_on", "failures"}: raise ValueError
        tid = task.get("id")
        if not isinstance(tid, str) or not _ID.fullmatch(tid) or tid in data: raise ValueError
        dur, fails = task.get("duration"), task.get("failures", 0)
        deps = task.get("depends_on", [])
        if not _integer(dur, 1, 1000) or not _integer(fails, 0, 8) or not isinstance(deps, list): raise ValueError
        if any(not isinstance(d, str) for d in deps) or len(set(deps)) != len(deps): raise ValueError
        data[tid] = (dur, fails, deps)
    for tid, (_, _, deps) in data.items():
        if tid in deps or any(d not in data for d in deps): raise ValueError
    # Validate acyclicity before execution.
    visiting, done = set(), set()
    def visit(t):
        if t in visiting: raise ValueError
        if t in done: return
        visiting.add(t)
        for d in data[t][2]: visit(d)
        visiting.remove(t); done.add(t)
    for t in data: visit(t)

    result = {}
    events = []
    running = {} # task -> (finish, attempt)
    attempts = {t: 0 for t in data}
    now = 0
    while len(result) < len(data):
        if running:
            now = min(v[0] for v in running.values())
        # Complete all simultaneous attempts by ID.
        for t in sorted([t for t,v in running.items() if v[0] == now]):
            finish, n = running.pop(t)
            attempts[t] = n
            if n <= data[t][1]:
                typ = "retry" if n <= retries else "failed"
                if typ == "failed": result[t] = {"state":"failed", "attempts":n, "finish":now}
            else:
                typ = "succeeded"; result[t] = {"state":"succeeded", "attempts":n, "finish":now}
            events.append({"time":now,"task":t,"attempt":n,"type":typ})
        # Propagate skips in lexicographic waves until stable.
        while True:
            wave = [t for t in data if t not in result and t not in running and any(d in result and result[d]["state"] != "succeeded" for d in data[t][2])]
            if not wave: break
            for t in sorted(wave):
                result[t] = {"state":"skipped","attempts":0,"finish":now}
                events.append({"time":now,"task":t,"attempt":0,"type":"skipped"})
        # Launch available ready work.
        while len(running) < workers:
            ready = sorted(t for t in data if t not in result and t not in running and all(d in result and result[d]["state"] == "succeeded" for d in data[t][2]))
            if not ready: break
            t = ready[0]; n = attempts[t] + 1
            running[t] = (now + data[t][0], n)
            events.append({"time":now,"task":t,"attempt":n,"type":"start"})
        if not running:
            break
    return {"makespan": max((v["finish"] for v in result.values()), default=0), "tasks": {t: result[t] for t in sorted(result)}, "events":events}
