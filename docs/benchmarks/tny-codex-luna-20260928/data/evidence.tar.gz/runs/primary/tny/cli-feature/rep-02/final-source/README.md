journal.py stores entries in a JSON file. Use `--file PATH` before a command.

- `python journal.py [--file PATH] add DATE TAG MINUTES` adds an entry.
- `python journal.py [--file PATH] list` lists entries.
- `python journal.py [--file PATH] stats [--since YYYY-MM-DD] [--tag TAG]` reports JSON with exactly `count` and `total_minutes`. `--since` includes entries on or after the date; `--tag` selects an exact tag. Invalid dates are rejected.

Run `python journal.py --help` or `python journal.py stats --help` for command help.
