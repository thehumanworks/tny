def earliest(events):
    """Return the event with the earliest absolute ISO-8601 instant."""
    from datetime import datetime
    return min(events, key=lambda event: datetime.fromisoformat(event["ts"].replace("Z", "+00:00")).timestamp())
