# Journal

`journal.py` stores entries in a JSON file. Use `--file PATH` before a command to select the data file (default: `journal.json`).

- `python journal.py [--file PATH] add DATE TAG MINUTES` adds an entry.
- `python journal.py [--file PATH] list` prints all entries as JSON.
- `python journal.py [--file PATH] stats [--since YYYY-MM-DD] [--tag TAG]` prints JSON containing exactly `count` and `total_minutes`. Filters can be combined; `--since` includes entries on or after the given valid date.

Run `python journal.py --help` or `python journal.py stats --help` for command help.
