def nearest_rank(values, fraction):
    """Return the nearest-rank percentile for 0 < fraction <= 1."""
    ordered = sorted(values)
    return ordered[max(0, min(len(ordered) - 1, __import__("math").ceil(fraction * len(ordered)) - 1))]
