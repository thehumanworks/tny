def reserve(stock, lines):
    """Reserve all requested (sku, quantity) lines or leave stock unchanged."""
    requested = {}
    for sku, quantity in lines:
        requested[sku] = requested.get(sku, 0) + quantity
    if any(stock.get(sku, 0) < quantity for sku, quantity in requested.items()):
        return False
    for sku, quantity in requested.items():
        stock[sku] -= quantity
    return True
