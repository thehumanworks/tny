def tax_due(cents, brackets):
    """Return progressive tax in cents for (ceiling, percent) brackets."""
    tax = 0
    lower = 0
    for ceiling, rate in brackets:
        taxable = max(0, min(cents, ceiling) - lower)
        tax += taxable * rate // 100
        if cents <= ceiling:
            return tax
        lower = ceiling
    return tax
