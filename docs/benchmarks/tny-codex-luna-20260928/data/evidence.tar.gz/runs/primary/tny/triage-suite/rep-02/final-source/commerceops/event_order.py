from datetime import datetime

def earliest(events):
    """Return the event with the earliest absolute ISO-8601 instant."""
    def instant(event):
        return datetime.fromisoformat(event["ts"].replace("Z", "+00:00")).timestamp()
    return min(events, key=instant)
