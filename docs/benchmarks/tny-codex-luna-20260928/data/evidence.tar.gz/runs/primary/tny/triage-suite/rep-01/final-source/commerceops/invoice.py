def next_number(existing):
    """Find the next INV sequence number."""
    return f"INV-{max((int(item.rsplit('-', 1)[-1]) for item in existing), default=0) + 1}"
