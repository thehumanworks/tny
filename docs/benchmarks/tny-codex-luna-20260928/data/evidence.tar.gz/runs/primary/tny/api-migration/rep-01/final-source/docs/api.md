# Record access

`RecordStore.resolve(scope, identifier, *, as_of=None)` returns a `Resolution` with `found`, `value`, `revision`, and `reason`. Reasons are `found`, `absent`, `deleted`, and `expired`. Explicit null payloads are found; clients use their fallback only when `found` is false.

Historical reads select the newest record at or before `as_of`. Tombstones mask older records. Expiration applies when the query revision reaches `expires_at`; head reads use the store-wide greatest revision as the expiry clock. Negative revisions raise `ValueError`. Absent resolutions have no revision; deleted and expired resolutions retain the selected record revision.

Client readers preserve their public signatures and pass historical revisions through to `resolve`.
