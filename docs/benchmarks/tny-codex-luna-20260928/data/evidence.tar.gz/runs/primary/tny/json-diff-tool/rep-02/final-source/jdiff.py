import argparse
import json
from pathlib import Path


def _pointer(parts):
    return "" if not parts else "/" + "/".join(str(part).replace("~", "~0").replace("/", "~1") for part in parts)


def _is_ignored(path, ignored):
    # Pointer boundaries matter: /a must not suppress /ab.
    return any(path == prefix or (prefix == "" and path.startswith("/")) or path.startswith(prefix + "/") for prefix in ignored)


def diff_values(left, right, ignored=()):
    ignored = tuple(ignored)
    changes = []

    def walk(before, after, parts):
        path = _pointer(parts)
        if _is_ignored(path, ignored):
            return
        # JSON types distinguish booleans from integers in Python.
        if type(before) is not type(after):
            changes.append({"path": path, "kind": "changed", "before": before, "after": after})
        elif isinstance(before, dict):
            keys = sorted(set(before) | set(after))
            for key in keys:
                child_parts = parts + (key,)
                child_path = _pointer(child_parts)
                if _is_ignored(child_path, ignored):
                    continue
                if key not in before:
                    changes.append({"path": child_path, "kind": "added", "after": after[key]})
                elif key not in after:
                    changes.append({"path": child_path, "kind": "removed", "before": before[key]})
                else:
                    walk(before[key], after[key], child_parts)
        elif isinstance(before, list):
            for index in range(max(len(before), len(after))):
                child_parts = parts + (index,)
                child_path = _pointer(child_parts)
                if _is_ignored(child_path, ignored):
                    continue
                if index >= len(before):
                    changes.append({"path": child_path, "kind": "added", "after": after[index]})
                elif index >= len(after):
                    changes.append({"path": child_path, "kind": "removed", "before": before[index]})
                else:
                    walk(before[index], after[index], child_parts)
        elif before != after:
            changes.append({"path": path, "kind": "changed", "before": before, "after": after})

    walk(left, right, ())
    return sorted(changes, key=lambda change: (change["path"], change["kind"]))


def main():
    parser = argparse.ArgumentParser(description="Compare two JSON files")
    parser.add_argument("left")
    parser.add_argument("right")
    parser.add_argument("--ignore", action="append", default=[], metavar="POINTER", help="Ignore a JSON Pointer and its descendants")
    parser.add_argument("--summary", action="store_true", help="Print counts by change kind")
    args = parser.parse_args()
    left = json.loads(Path(args.left).read_text())
    right = json.loads(Path(args.right).read_text())
    changes = diff_values(left, right, args.ignore)
    if args.summary:
        output = {kind: sum(change["kind"] == kind for change in changes) for kind in ("added", "removed", "changed")}
    else:
        output = changes
    print(json.dumps(output))


if __name__ == "__main__":
    main()
