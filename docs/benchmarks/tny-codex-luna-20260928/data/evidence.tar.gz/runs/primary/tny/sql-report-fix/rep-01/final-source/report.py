import argparse
import json
import sqlite3


def customer_report(conn, customer_id):
    billed, paid = conn.execute(
        "SELECT COALESCE(SUM(lines.billed_cents),0), COALESCE(SUM(pays.paid_cents),0) "
        "FROM orders ord LEFT JOIN ("
        " SELECT order_id, SUM(qty*unit_cents) AS billed_cents "
        " FROM order_lines GROUP BY order_id"
        ") lines ON lines.order_id=ord.id LEFT JOIN ("
        " SELECT order_id, SUM(amount_cents) AS paid_cents "
        " FROM payments GROUP BY order_id"
        ") pays ON pays.order_id=ord.id WHERE ord.customer_id=?",
        (customer_id,),
    ).fetchone()
    return {"billed_cents": billed, "paid_cents": paid, "due_cents": billed - paid}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("database")
    parser.add_argument("customer_id", type=int)
    args = parser.parse_args()
    with sqlite3.connect(args.database) as conn:
        print(json.dumps(customer_report(conn, args.customer_id)))


if __name__ == "__main__":
    main()
