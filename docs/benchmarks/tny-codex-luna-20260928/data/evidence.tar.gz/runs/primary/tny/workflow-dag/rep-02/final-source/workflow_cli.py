import json
import sys
from workflow import simulate


def main():
    try:
        obj = json.load(sys.stdin)
        if not isinstance(obj, dict) or set(obj) - {"tasks", "workers", "retries"} or "tasks" not in obj:
            raise ValueError
        result = simulate(obj["tasks"], obj.get("workers", 2), obj.get("retries", 1))
    except (ValueError, TypeError, json.JSONDecodeError):
        print(json.dumps({"error": "ValueError"}))
        return 2
    print(json.dumps(result))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
