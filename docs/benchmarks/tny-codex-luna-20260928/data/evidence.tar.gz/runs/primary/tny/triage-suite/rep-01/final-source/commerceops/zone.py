def zone_for(postcode, prefix_to_zone, default):
    """Choose the most-specific matching postal prefix."""
    matches = [(prefix, zone) for prefix, zone in prefix_to_zone.items() if postcode.startswith(prefix)]
    return max(matches, key=lambda item: len(item[0]))[1] if matches else default
