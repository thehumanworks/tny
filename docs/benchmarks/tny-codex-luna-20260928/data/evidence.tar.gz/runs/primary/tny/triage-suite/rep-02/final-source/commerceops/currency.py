def convert_minor(cents, numerator, denominator):
    """Convert integer minor units, rounding half away from zero."""
    n = cents * numerator
    d = denominator
    sign = -1 if n * d < 0 else 1
    q, r = divmod(abs(n), abs(d))
    return sign * (q + (2 * r >= abs(d)))
