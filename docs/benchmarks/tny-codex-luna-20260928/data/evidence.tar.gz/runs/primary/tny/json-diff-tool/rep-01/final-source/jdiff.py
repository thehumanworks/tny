import argparse
import json
from pathlib import Path


def _pointer(parts):
    return "".join("/" + str(part).replace("~", "~0").replace("/", "~1") for part in parts)


def _same_type(a, b):
    # JSON booleans are distinct from numbers despite Python's bool subclassing int.
    return type(a) is type(b)


def diff_values(left, right, ignored=()):
    ignored = set(ignored)
    changes = []

    def visit(a, b, parts):
        path = _pointer(parts)
        if any(path == item or path.startswith(item.rstrip("/") + "/") for item in ignored):
            return
        if not _same_type(a, b):
            changes.append({"path": path, "kind": "changed", "before": a, "after": b})
        elif isinstance(a, dict):
            for key in sorted(a.keys() | b.keys()):
                child = parts + (key,)
                child_path = _pointer(child)
                if any(child_path == item or child_path.startswith(item.rstrip("/") + "/") for item in ignored):
                    continue
                if key not in a:
                    changes.append({"path": child_path, "kind": "added", "after": b[key]})
                elif key not in b:
                    changes.append({"path": child_path, "kind": "removed", "before": a[key]})
                else:
                    visit(a[key], b[key], child)
        elif isinstance(a, list):
            for i in range(max(len(a), len(b))):
                child = parts + (str(i),)
                child_path = _pointer(child)
                if any(child_path == item or child_path.startswith(item.rstrip("/") + "/") for item in ignored):
                    continue
                if i >= len(a):
                    changes.append({"path": child_path, "kind": "added", "after": b[i]})
                elif i >= len(b):
                    changes.append({"path": child_path, "kind": "removed", "before": a[i]})
                else:
                    visit(a[i], b[i], child)
        elif a != b:
            changes.append({"path": path, "kind": "changed", "before": a, "after": b})

    visit(left, right, ())
    return sorted(changes, key=lambda c: (c["path"], c["kind"]))


def main():
    parser = argparse.ArgumentParser(description="Compare two JSON files")
    parser.add_argument("left")
    parser.add_argument("right")
    parser.add_argument("--ignore", action="append", default=[], metavar="POINTER")
    parser.add_argument("--summary", action="store_true")
    args = parser.parse_args()
    left = json.loads(Path(args.left).read_text())
    right = json.loads(Path(args.right).read_text())
    changes = diff_values(left, right, args.ignore)
    if args.summary:
        output = {kind: sum(change["kind"] == kind for change in changes)
                  for kind in ("added", "removed", "changed")}
    else:
        output = changes
    print(json.dumps(output))


if __name__ == "__main__":
    main()
