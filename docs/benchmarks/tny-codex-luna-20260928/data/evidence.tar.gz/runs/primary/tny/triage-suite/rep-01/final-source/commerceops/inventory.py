def reserve(stock, lines):
    """Reserve all requested (sku, quantity) lines or leave stock unchanged."""
    needed = {}
    for sku, quantity in lines:
        needed[sku] = needed.get(sku, 0) + quantity
    if any(stock.get(sku, 0) < quantity for sku, quantity in needed.items()):
        return False
    for sku, quantity in needed.items():
        stock[sku] -= quantity
    return True
