import argparse
import json
from datetime import date
from pathlib import Path


def main(argv=None):
    parser = argparse.ArgumentParser(description="Daily work journal")
    parser.add_argument("--file", default="journal.json")
    commands = parser.add_subparsers(dest="command", required=True)
    add = commands.add_parser("add", help="add an entry")
    add.add_argument("date")
    add.add_argument("tag")
    add.add_argument("minutes", type=int)
    commands.add_parser("list", help="list entries")
    stats = commands.add_parser("stats", help="summarize entries")
    stats.add_argument("--since", metavar="YYYY-MM-DD", help="include entries on or after this date")
    stats.add_argument("--tag", help="include only entries with this tag")
    args = parser.parse_args(argv)
    path = Path(args.file)
    rows = json.loads(path.read_text()) if path.exists() else []
    if args.command == "add":
        rows.append(dict(date=args.date, tag=args.tag, minutes=args.minutes))
        path.write_text(json.dumps(rows))
    elif args.command == "list":
        print(json.dumps(rows))
    elif args.command == "stats":
        since = None
        if args.since is not None:
            try:
                since = date.fromisoformat(args.since)
                if since.isoformat() != args.since:
                    raise ValueError
            except ValueError:
                parser.error("--since must be a valid date in YYYY-MM-DD format")
        filtered = [row for row in rows
                    if (since is None or date.fromisoformat(row["date"]) >= since)
                    and (args.tag is None or row["tag"] == args.tag)]
        print(json.dumps({"count": len(filtered),
                          "total_minutes": sum(row["minutes"] for row in filtered)}))


if __name__ == "__main__":
    main()
