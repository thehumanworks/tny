def allocate_cents(total, weights):
    """Allocate all cents by largest remainder, ties by original index."""
    if not weights:
        return []
    denominator = sum(weights)
    if denominator == 0:
        return [0 for _ in weights]
    sign = -1 if total < 0 else 1
    magnitude = abs(total)
    exact = [magnitude * weight / denominator for weight in weights]
    result = [int(value) for value in exact]
    remainder = magnitude - sum(result)
    order = sorted(range(len(weights)), key=lambda i: (-(exact[i] - result[i]), i))
    for i in order[:remainder]:
        result[i] += 1
    return [sign * value for value in result]
