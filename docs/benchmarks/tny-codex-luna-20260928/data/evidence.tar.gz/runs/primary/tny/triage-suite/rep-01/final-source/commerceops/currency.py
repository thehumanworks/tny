def convert_minor(cents, numerator, denominator):
    """Convert integer minor units, rounding half away from zero."""
    from decimal import Decimal, ROUND_HALF_UP
    value = Decimal(cents) * Decimal(numerator) / Decimal(denominator)
    return int(value.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
