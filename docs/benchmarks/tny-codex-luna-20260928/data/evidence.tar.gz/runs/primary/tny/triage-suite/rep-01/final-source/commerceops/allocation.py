def allocate_cents(total, weights):
    """Allocate all cents by largest remainder, ties by original index."""
    if not weights:
        return []
    denominator = sum(weights)
    exact = [total * weight / denominator for weight in weights]
    result = [int(value) for value in exact]
    remainder = total - sum(result)
    order = sorted(range(len(weights)), key=lambda i: (-(exact[i] - result[i]), i))
    for i in order[:remainder]:
        result[i] += 1
    return result
