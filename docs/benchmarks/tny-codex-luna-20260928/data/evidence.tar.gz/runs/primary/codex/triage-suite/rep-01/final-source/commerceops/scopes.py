def allowed(granted, required):
    """Check exact comma-separated capability names."""
    return required in {scope.strip() for scope in granted.split(",")}
