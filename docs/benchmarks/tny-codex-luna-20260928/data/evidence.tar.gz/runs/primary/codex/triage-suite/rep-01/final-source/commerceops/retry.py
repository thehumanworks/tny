def should_retry(code, attempt, max_attempts):
    """Retry transient errors while attempts remain."""
    return code in {"timeout", "temporary_error", "network_error"} and attempt < max_attempts
