"""JSON command line interface for the workflow simulator."""

import json
import sys

from workflow import simulate


def main():
    try:
        request = json.load(sys.stdin)
        if not isinstance(request, dict) or set(request) - {"tasks", "workers", "retries"} or "tasks" not in request:
            raise ValueError
        result = simulate(request["tasks"], request.get("workers", 2), request.get("retries", 1))
    except (ValueError, TypeError, json.JSONDecodeError):
        sys.stdout.write('{"error":"ValueError"}\n')
        return 2
    sys.stdout.write(json.dumps(result, separators=(",", ":")) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
