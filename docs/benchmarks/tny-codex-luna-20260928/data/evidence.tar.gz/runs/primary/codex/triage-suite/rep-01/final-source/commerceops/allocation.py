def allocate_cents(total, weights):
    """Allocate all cents by largest remainder, ties by original index."""
    weight_sum = sum(weights)
    exact = [total * weight / weight_sum for weight in weights]
    allocated = [int(value) for value in exact]
    remaining = total - sum(allocated)
    order = sorted(range(len(weights)), key=lambda i: (exact[i] - allocated[i], -i), reverse=True)
    for i in order[:remaining]:
        allocated[i] += 1
    return allocated
