def convert_minor(cents, numerator, denominator):
    """Convert integer minor units, rounding half away from zero."""
    product = cents * numerator
    divisor = denominator
    sign = -1 if product * divisor < 0 else 1
    quotient, remainder = divmod(abs(product), abs(divisor))
    return sign * (quotient + (2 * remainder >= abs(divisor)))
