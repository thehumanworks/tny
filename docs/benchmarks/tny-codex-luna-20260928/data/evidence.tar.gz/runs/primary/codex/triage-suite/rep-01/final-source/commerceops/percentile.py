def nearest_rank(values, fraction):
    """Return the nearest-rank percentile for 0 < fraction <= 1."""
    ordered = sorted(values)
    import math

    return ordered[max(0, math.ceil(fraction * len(ordered)) - 1)]
