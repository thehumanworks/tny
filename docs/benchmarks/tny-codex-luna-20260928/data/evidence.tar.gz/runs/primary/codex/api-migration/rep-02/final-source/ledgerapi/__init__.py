"""Versioned tenant configuration API."""
from .store import Record, RecordStore, Resolution

__all__ = ["Record", "RecordStore", "Resolution"]
