def next_number(existing):
    """Find the next INV sequence number."""
    latest = max((int(number.split("-")[-1]) for number in existing), default=0)
    return f"INV-{latest + 1}"
