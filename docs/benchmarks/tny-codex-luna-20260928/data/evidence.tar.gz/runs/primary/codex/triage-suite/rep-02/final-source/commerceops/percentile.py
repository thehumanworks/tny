def nearest_rank(values, fraction):
    """Return the nearest-rank percentile for 0 < fraction <= 1."""
    ordered = sorted(values)
    rank = max(1, int(fraction * len(ordered) + 0.999999999))
    return ordered[rank - 1]
