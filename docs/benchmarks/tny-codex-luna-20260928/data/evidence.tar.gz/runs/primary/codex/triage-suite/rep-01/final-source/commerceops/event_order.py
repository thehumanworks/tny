def earliest(events):
    """Return the event with the earliest absolute ISO-8601 instant."""
    from datetime import datetime

    def instant(event):
        return datetime.fromisoformat(event["ts"].replace("Z", "+00:00"))

    return min(events, key=instant)
