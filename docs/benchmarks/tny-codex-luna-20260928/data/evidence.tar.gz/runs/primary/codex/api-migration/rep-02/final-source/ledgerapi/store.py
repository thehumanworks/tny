"""Versioned tenant record resolution."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Record:
    scope: str
    identifier: str
    value: object
    revision: int
    expires_at: int | None = None
    deleted: bool = False


@dataclass(frozen=True)
class Resolution:
    found: bool
    value: object
    revision: int | None
    reason: str


class RecordStore:
    def __init__(self, records=()):
        self.records = list(records)

    def resolve(self, scope, identifier, *, as_of=None):
        """Resolve the visible record at a revision or at the current head."""
        if as_of is not None and as_of < 0:
            raise ValueError("as_of must be nonnegative")
        head = max((record.revision for record in self.records), default=None)
        query_revision = head if as_of is None else as_of
        matching = [
            record
            for record in self.records
            if record.scope == scope and record.identifier == identifier
            and (as_of is None or record.revision <= as_of)
        ]
        if not matching:
            return Resolution(False, None, None, "absent")
        latest = max(matching, key=lambda record: record.revision)
        if latest.deleted:
            return Resolution(False, None, latest.revision, "deleted")
        if latest.expires_at is not None and query_revision is not None and query_revision >= latest.expires_at:
            return Resolution(False, None, latest.revision, "expired")
        return Resolution(True, latest.value, latest.revision, "found")

    def append(self, record):
        self.records.append(record)
