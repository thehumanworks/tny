"""Deterministic discrete-time simulation of a small dependency workflow."""

import re


_TASK_ID = re.compile(r"[A-Za-z][A-Za-z0-9_-]{0,31}\Z", re.ASCII)


def _bounded_int(value, low, high):
    return isinstance(value, int) and not isinstance(value, bool) and low <= value <= high


def _validate(tasks, workers, retries):
    if not _bounded_int(workers, 1, 8) or not _bounded_int(retries, 0, 8):
        raise ValueError
    if not isinstance(tasks, list) or len(tasks) > 32:
        raise ValueError

    by_id = {}
    for task in tasks:
        if not isinstance(task, dict) or set(task) - {"id", "duration", "depends_on", "failures"}:
            raise ValueError
        ident = task.get("id")
        duration = task.get("duration")
        if not isinstance(ident, str) or _TASK_ID.fullmatch(ident) is None:
            raise ValueError
        if ident in by_id or not _bounded_int(duration, 1, 1000):
            raise ValueError
        failures = task.get("failures", 0)
        if not _bounded_int(failures, 0, 8):
            raise ValueError
        deps = task.get("depends_on", [])
        if not isinstance(deps, list):
            raise ValueError
        if any(not isinstance(dep, str) for dep in deps) or len(set(deps)) != len(deps):
            raise ValueError
        by_id[ident] = {"duration": duration, "failures": failures, "deps": list(deps)}

    for ident, task in by_id.items():
        if any(dep not in by_id or dep == ident for dep in task["deps"]):
            raise ValueError

    # A topological count check rejects all cycles before any scheduling begins.
    remaining = {ident: len(task["deps"]) for ident, task in by_id.items()}
    children = {ident: [] for ident in by_id}
    for ident, task in by_id.items():
        for dep in task["deps"]:
            children[dep].append(ident)
    ready = [ident for ident, count in remaining.items() if count == 0]
    seen = 0
    while ready:
        ident = ready.pop()
        seen += 1
        for child in children[ident]:
            remaining[child] -= 1
            if remaining[child] == 0:
                ready.append(child)
    if seen != len(by_id):
        raise ValueError
    return by_id


def simulate(tasks, workers=2, retries=1):
    """Run a deterministic workflow simulation and return its event log."""
    specs = _validate(tasks, workers, retries)
    states = {ident: {"state": "pending", "attempts": 0, "finish": None}
              for ident in specs}
    running = {}  # ident -> (finish time, attempt number)
    events = []
    now = 0

    while any(item["state"] == "pending" for item in states.values()) or running:
        # Complete every attempt at this time before reconsidering dependencies.
        completions = sorted((ident for ident, (finish, _) in running.items()
                              if finish == now))
        for ident in completions:
            _, attempt = running.pop(ident)
            spec = specs[ident]
            if attempt <= spec["failures"]:
                if attempt <= retries:
                    events.append({"time": now, "task": ident, "attempt": attempt, "type": "retry"})
                else:
                    states[ident].update(state="failed", finish=now)
                    events.append({"time": now, "task": ident, "attempt": attempt, "type": "failed"})
            else:
                states[ident].update(state="succeeded", finish=now)
                events.append({"time": now, "task": ident, "attempt": attempt, "type": "succeeded"})

        # Propagate skips in lexicographic waves. A newly skipped task can
        # make its descendants skippable in the next wave at this same time.
        while True:
            skipped = [ident for ident, state in states.items()
                       if state["state"] == "pending" and
                       any(states[dep]["state"] in ("failed", "skipped")
                           for dep in specs[ident]["deps"])]
            if not skipped:
                break
            for ident in sorted(skipped):
                states[ident].update(state="skipped", finish=now)
                events.append({"time": now, "task": ident, "attempt": 0, "type": "skipped"})

        # A retry is just a pending task and competes by ID with newly ready work.
        slots = workers - len(running)
        ready = [ident for ident, state in states.items()
                 if state["state"] == "pending" and
                 all(states[dep]["state"] == "succeeded" for dep in specs[ident]["deps"])]
        for ident in sorted(ready)[:slots]:
            attempt = states[ident]["attempts"] + 1
            states[ident]["attempts"] = attempt
            running[ident] = (now + specs[ident]["duration"], attempt)
            events.append({"time": now, "task": ident, "attempt": attempt, "type": "start"})

        if running:
            now = min(finish for finish, _ in running.values())
        elif any(item["state"] == "pending" for item in states.values()):
            # This should be unreachable after validation, but avoids a hang if
            # the state machine is changed independently of graph validation.
            raise RuntimeError("workflow made no progress")

    makespan = max((item["finish"] for item in states.values()), default=0)
    result_tasks = {ident: {"state": states[ident]["state"],
                            "attempts": states[ident]["attempts"],
                            "finish": states[ident]["finish"]}
                    for ident in sorted(states)}
    return {"makespan": makespan, "tasks": result_tasks, "events": events}
