def tax_due(cents, brackets):
    """Return progressive tax in cents for (ceiling, percent) brackets."""
    taxable_from = 0
    tax = 0
    for ceiling, rate in brackets:
        amount = min(cents, ceiling) - taxable_from
        if amount > 0:
            tax += amount * rate // 100
        if cents <= ceiling:
            return tax
        taxable_from = ceiling
    if cents > taxable_from:
        tax += (cents - taxable_from) * brackets[-1][1] // 100
    return tax
