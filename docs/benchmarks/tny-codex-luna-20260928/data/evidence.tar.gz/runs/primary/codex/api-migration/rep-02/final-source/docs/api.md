# Versioned tenant record API

`RecordStore.resolve(scope, identifier, *, as_of=None)` returns a `Resolution`
with `found`, `value`, `revision`, and `reason`. Reasons are `found`, `absent`,
`deleted`, or `expired`. Stored null values are found and do not trigger a
client fallback. An absent key has no revision; deleted and expired results
report the selected record's revision.

Historical reads select the greatest record revision no newer than `as_of`.
Tombstones mask earlier records. Expiration applies when the query revision is
greater than or equal to `expires_at`; a head read uses the greatest revision
in the store as its expiry clock. Negative `as_of` values are invalid.

Client reader signatures remain stable. They pass `as_of` through to
`resolve(scope, identifier, *, as_of=None)` and use their fallback only when
`found` is false. The persisted `domain:name` key format is unchanged.
