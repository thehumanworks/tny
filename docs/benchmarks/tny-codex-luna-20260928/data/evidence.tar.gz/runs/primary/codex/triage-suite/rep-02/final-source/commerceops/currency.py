def convert_minor(cents, numerator, denominator):
    """Convert integer minor units, rounding half away from zero."""
    scaled = cents * numerator
    divisor = denominator
    sign = -1 if scaled * divisor < 0 else 1
    quotient, remainder = divmod(abs(scaled), abs(divisor))
    if remainder * 2 >= abs(divisor):
        quotient += 1
    return sign * quotient
