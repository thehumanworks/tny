"""Versioned tenant record resolution."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Record:
    scope: str
    identifier: str
    value: object
    revision: int
    expires_at: int | None = None
    deleted: bool = False


@dataclass(frozen=True)
class Resolution:
    found: bool
    value: object
    revision: int | None
    reason: str


class RecordStore:
    def __init__(self, records=()):
        self.records = list(records)

    def resolve(self, scope, identifier, *, as_of=None):
        """Resolve the visible record at a revision or at the current head."""
        if as_of is not None and as_of < 0:
            raise ValueError("as_of must be non-negative")

        matching = [
            record
            for record in self.records
            if record.scope == scope
            and record.identifier == identifier
            and (as_of is None or record.revision <= as_of)
        ]
        if not matching:
            return Resolution(False, None, None, "absent")

        selected = max(matching, key=lambda record: record.revision)
        if selected.deleted:
            return Resolution(False, None, selected.revision, "deleted")

        clock = as_of if as_of is not None else max(
            record.revision for record in self.records
        )
        if selected.expires_at is not None and clock >= selected.expires_at:
            return Resolution(False, None, selected.revision, "expired")

        return Resolution(True, selected.value, selected.revision, "found")

    def append(self, record):
        self.records.append(record)
