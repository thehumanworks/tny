def encode(value):
    """Encode one RFC 4180-style CSV cell."""
    text = str(value)
    if any(char in text for char in ',"\r\n'):
        return '"' + text.replace('"', '""') + '"'
    return text
