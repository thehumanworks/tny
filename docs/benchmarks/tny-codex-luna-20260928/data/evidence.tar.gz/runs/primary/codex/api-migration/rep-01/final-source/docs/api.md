# Record access

`RecordStore.resolve(scope, identifier, *, as_of=None)` returns a `Resolution`
with `found`, `value`, `revision`, and `reason` fields. Reasons are `found`,
`absent`, `deleted`, and `expired`. A stored null payload is a found record,
not a missing key or fallback.

Historical resolution selects the newest record at or before `as_of`; a
negative revision is invalid. A tombstone masks older records. Expiry occurs
when the query revision is greater than or equal to `expires_at`. For a head
query, the greatest revision in the store is the expiry clock. Absent keys have
no revision; deleted and expired resolutions report the selected record's
revision.

Client readers pass `as_of` through to resolution and use their fallback only
when `found` is false. Their key format and public signatures are unchanged.
