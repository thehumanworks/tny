def zone_for(postcode, prefix_to_zone, default):
    """Choose the most-specific matching postal prefix."""
    matches = (prefix for prefix in prefix_to_zone if postcode.startswith(prefix))
    prefix = max(matches, key=len, default=None)
    return default if prefix is None else prefix_to_zone[prefix]
