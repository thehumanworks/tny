def allocate_cents(total, weights):
    """Allocate all cents by largest remainder, ties by original index."""
    weight_sum = sum(weights)
    if not weights or weight_sum == 0:
        return [0 for _ in weights]
    sign = -1 if total < 0 else 1
    magnitude = abs(total)
    quotas = [magnitude * weight / weight_sum for weight in weights]
    shares = [int(quota) for quota in quotas]
    remaining = magnitude - sum(shares)
    order = sorted(range(len(weights)), key=lambda i: (-(quotas[i] - shares[i]), i))
    for i in order[:remaining]:
        shares[i] += 1
    return [sign * share for share in shares]
