import argparse
import json
from pathlib import Path


def diff_values(left, right, ignored=()):
    """Return a stable list of changes between two JSON-compatible values."""
    ignored = tuple(_normalize_pointer(pointer) for pointer in ignored)
    changes = []

    def visit(before, after, path):
        if any(path == pointer or path.startswith(pointer + "/") for pointer in ignored):
            return

        # JSON booleans and numbers need distinct treatment in Python, where
        # bool is a subclass of int.
        if type(before) is not type(after):
            changes.append({"path": path, "kind": "changed", "before": before, "after": after})
            return

        if isinstance(before, dict):
            keys = sorted(set(before) | set(after))
            for key in keys:
                child_path = path + "/" + _escape_pointer_component(key)
                if key not in before:
                    if not _is_ignored(child_path, ignored):
                        changes.append({"path": child_path, "kind": "added", "after": after[key]})
                elif key not in after:
                    if not _is_ignored(child_path, ignored):
                        changes.append({"path": child_path, "kind": "removed", "before": before[key]})
                else:
                    visit(before[key], after[key], child_path)
            return

        if isinstance(before, list):
            for index in range(max(len(before), len(after))):
                child_path = path + "/" + str(index)
                if index >= len(before):
                    if not _is_ignored(child_path, ignored):
                        changes.append({"path": child_path, "kind": "added", "after": after[index]})
                elif index >= len(after):
                    if not _is_ignored(child_path, ignored):
                        changes.append({"path": child_path, "kind": "removed", "before": before[index]})
                else:
                    visit(before[index], after[index], child_path)
            return

        if before != after:
            changes.append({"path": path, "kind": "changed", "before": before, "after": after})

    visit(left, right, "")
    changes.sort(key=lambda change: (change["path"], change["kind"]))
    return changes


def _escape_pointer_component(component):
    return str(component).replace("~", "~0").replace("/", "~1")


def _normalize_pointer(pointer):
    # Accept the empty root pointer or a slash-prefixed JSON Pointer. Keeping
    # caller spelling intact makes prefix checks operate on encoded components.
    if not isinstance(pointer, str) or (pointer and not pointer.startswith("/")):
        raise ValueError("ignored paths must be JSON Pointers")
    return pointer


def _is_ignored(path, ignored):
    return any(path == pointer or path.startswith(pointer + "/") for pointer in ignored)


def main():
    parser = argparse.ArgumentParser(description="Inspect two JSON files")
    parser.add_argument("left")
    parser.add_argument("right")
    parser.add_argument("--ignore", action="append", default=[], metavar="POINTER")
    parser.add_argument("--summary", action="store_true")
    args = parser.parse_args()
    left = json.loads(Path(args.left).read_text())
    right = json.loads(Path(args.right).read_text())
    changes = diff_values(left, right, args.ignore)
    if args.summary:
        output = {kind: sum(change["kind"] == kind for change in changes)
                  for kind in ("added", "removed", "changed")}
    else:
        output = changes
    print(json.dumps(output))


if __name__ == "__main__":
    main()
