journal.py stores entries in a JSON file. Use --file PATH, then run:

- `add DATE TAG MINUTES` to add an entry
- `list` to print all entries
- `stats [--since YYYY-MM-DD] [--tag TAG]` to print JSON containing `count` and `total_minutes`

The `stats` filters can be used together. `--since` includes entries on or after the given date and must be a valid `YYYY-MM-DD` date.
