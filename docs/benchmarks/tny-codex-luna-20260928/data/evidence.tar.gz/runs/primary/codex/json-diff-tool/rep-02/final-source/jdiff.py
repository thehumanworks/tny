import argparse
import json
from pathlib import Path


def diff_values(left, right, ignored=()):
    """Return a stable list of differences between two JSON values."""
    ignored = tuple(ignored)
    changes = []

    def visit(before, after, path):
        if any(path == prefix or path.startswith(prefix + "/") for prefix in ignored):
            return

        # JSON distinguishes booleans from numbers despite Python's bool subclassing int.
        if type(before) is not type(after):
            changes.append({"path": path, "kind": "changed", "before": before, "after": after})
        elif isinstance(before, dict):
            keys = sorted(before.keys() | after.keys())
            for key in keys:
                child = path + "/" + str(key).replace("~", "~0").replace("/", "~1")
                if key not in before:
                    if not any(child == prefix or child.startswith(prefix + "/") for prefix in ignored):
                        changes.append({"path": child, "kind": "added", "after": after[key]})
                elif key not in after:
                    if not any(child == prefix or child.startswith(prefix + "/") for prefix in ignored):
                        changes.append({"path": child, "kind": "removed", "before": before[key]})
                else:
                    visit(before[key], after[key], child)
        elif isinstance(before, list):
            for index in range(max(len(before), len(after))):
                child = path + "/" + str(index)
                if index >= len(before):
                    if not any(child == prefix or child.startswith(prefix + "/") for prefix in ignored):
                        changes.append({"path": child, "kind": "added", "after": after[index]})
                elif index >= len(after):
                    if not any(child == prefix or child.startswith(prefix + "/") for prefix in ignored):
                        changes.append({"path": child, "kind": "removed", "before": before[index]})
                else:
                    visit(before[index], after[index], child)
        elif before != after:
            changes.append({"path": path, "kind": "changed", "before": before, "after": after})

    visit(left, right, "")
    return sorted(changes, key=lambda change: (change["path"], change["kind"]))


def main():
    parser = argparse.ArgumentParser(description="Inspect two JSON files")
    parser.add_argument("left")
    parser.add_argument("right")
    parser.add_argument("--ignore", action="append", default=[], metavar="POINTER",
                        help="ignore a JSON Pointer path and its descendants (repeatable)")
    parser.add_argument("--summary", action="store_true",
                        help="print counts by change kind instead of the change list")
    args = parser.parse_args()
    left = json.loads(Path(args.left).read_text())
    right = json.loads(Path(args.right).read_text())
    changes = diff_values(left, right, args.ignore)
    if args.summary:
        result = {kind: sum(change["kind"] == kind for change in changes)
                  for kind in ("added", "removed", "changed")}
    else:
        result = changes
    print(json.dumps(result))


if __name__ == "__main__":
    main()
