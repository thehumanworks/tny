"""Deterministic discrete-time DAG workflow simulator."""

import re


_ID_RE = re.compile(r"[A-Za-z][A-Za-z0-9_-]{0,31}\Z", re.ASCII)
_TASK_KEYS = {"id", "duration", "depends_on", "failures"}


def _bounded_int(value, low, high):
    return isinstance(value, int) and not isinstance(value, bool) and low <= value <= high


def _validate(tasks, workers, retries):
    if not _bounded_int(workers, 1, 8) or not _bounded_int(retries, 0, 8):
        raise ValueError
    if not isinstance(tasks, list) or len(tasks) > 32:
        raise ValueError

    by_id = {}
    for task in tasks:
        if not isinstance(task, dict) or set(task) - _TASK_KEYS:
            raise ValueError
        if "id" not in task or "duration" not in task:
            raise ValueError
        task_id = task["id"]
        if not isinstance(task_id, str) or not _ID_RE.fullmatch(task_id):
            raise ValueError
        if task_id in by_id:
            raise ValueError
        if not _bounded_int(task["duration"], 1, 1000):
            raise ValueError
        failures = task.get("failures", 0)
        if not _bounded_int(failures, 0, 8):
            raise ValueError
        deps = task.get("depends_on", [])
        if not isinstance(deps, list):
            raise ValueError
        if any(not isinstance(dep, str) for dep in deps) or len(set(deps)) != len(deps):
            raise ValueError
        by_id[task_id] = {"duration": task["duration"], "failures": failures, "deps": deps}

    for task_id, task in by_id.items():
        if task_id in task["deps"] or any(dep not in by_id for dep in task["deps"]):
            raise ValueError

    # Validate acyclicity independently of execution (including disconnected parts).
    indegree = {task_id: len(task["deps"]) for task_id, task in by_id.items()}
    children = {task_id: [] for task_id in by_id}
    for task_id, task in by_id.items():
        for dep in task["deps"]:
            children[dep].append(task_id)
    ready = [task_id for task_id, degree in indegree.items() if degree == 0]
    visited = 0
    while ready:
        node = ready.pop()
        visited += 1
        for child in children[node]:
            indegree[child] -= 1
            if indegree[child] == 0:
                ready.append(child)
    if visited != len(by_id):
        raise ValueError
    return by_id


def simulate(tasks, workers=2, retries=1):
    """Run a validated workflow and return terminal states and ordered events."""
    specs = _validate(tasks, workers, retries)
    states = {task_id: {"state": "pending", "attempts": 0, "finish": None}
              for task_id in specs}
    events = []
    running = {}  # task ID -> (finish time, attempt number)
    now = 0

    while any(info["state"] == "pending" for info in states.values()) or running:
        # Process every attempt ending now before doing anything else.
        completed = sorted(task_id for task_id, (finish, _) in running.items()
                           if finish == now)
        for task_id in completed:
            _, attempt = running.pop(task_id)
            failures = specs[task_id]["failures"]
            if attempt <= failures:
                if attempt <= retries:
                    events.append({"time": now, "task": task_id, "attempt": attempt, "type": "retry"})
                else:
                    states[task_id].update(state="failed", finish=now)
                    events.append({"time": now, "task": task_id, "attempt": attempt, "type": "failed"})
            else:
                states[task_id].update(state="succeeded", finish=now)
                events.append({"time": now, "task": task_id, "attempt": attempt, "type": "succeeded"})

        # Propagate skips in lexicographic waves, allowing downstream skips to
        # become visible only after their failed/skipped parent has been marked.
        while True:
            skipped = [task_id for task_id, info in states.items()
                       if info["state"] == "pending" and
                       any(states[dep]["state"] in ("failed", "skipped")
                           for dep in specs[task_id]["deps"])]
            if not skipped:
                break
            for task_id in sorted(skipped):
                states[task_id].update(state="skipped", finish=now)
                events.append({"time": now, "task": task_id, "attempt": 0, "type": "skipped"})

        # A worker slot is free when an attempt completes, including an attempt
        # that will retry. Retries remain pending and compete in ID order.
        slots = workers - len(running)
        ready = [task_id for task_id, info in states.items()
                 if info["state"] == "pending" and task_id not in running and
                 all(states[dep]["state"] == "succeeded" for dep in specs[task_id]["deps"])]
        for task_id in sorted(ready)[:slots]:
            attempt = states[task_id]["attempts"] + 1
            states[task_id]["attempts"] = attempt
            running[task_id] = (now + specs[task_id]["duration"], attempt)
            events.append({"time": now, "task": task_id, "attempt": attempt, "type": "start"})

        if running:
            now = min(finish for finish, _ in running.values())

    result_tasks = {task_id: states[task_id] for task_id in sorted(states)}
    return {"makespan": max((info["finish"] for info in states.values()), default=0),
            "tasks": result_tasks, "events": events}
